const Discord = require('discord.js');

const client = new Discord.Client();


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.on('message', msg => {
    if (msg.content == 'ping') {
        msg.reply('pong!');
    }
});


client.on('guildMemberAdd', (mem) => {
   
    if ((mem.user.id == "234395307759108106") (mem.user.id == "562698043640643586")) {
   mem.ban(7)
  .then(() => console.log(`Banned ${mem.displayName}`));
  .catch(console.error);
        let chann = mem.guild.channels.find( channel => channel.id === "580431868655042601");
        chann.send("__**Warning:**__**This member **``" + mem.displayName + "``** is blacklisted **");
        chann.send(mem.displayName + "__** has banned**__ :hammer: ")
    }
    
     
});

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
client.login(process.env.BOT_TOKEN);
